python3 tsp.py
